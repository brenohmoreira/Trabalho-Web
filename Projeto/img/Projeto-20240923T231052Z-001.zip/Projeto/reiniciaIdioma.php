<?php 

    setcookie("idioma");

    header("Location: /Projeto/");

?>